
    session["messaggio"] = ""
    session["mosse"] = 0